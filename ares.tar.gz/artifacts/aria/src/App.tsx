import { useState, useEffect, useRef } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import LeaderboardPage from "@/pages/leaderboard";
import PlayerPage from "@/pages/player";
import NotFound from "@/pages/not-found";
import ARIAOverlay from "@/components/ARIAOverlay";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 5_000, refetchInterval: 5_000 },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={LeaderboardPage} />
      <Route path="/player/:username" component={PlayerPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [ariaOpen, setAriaOpen] = useState(false);

  // ── keyboard state ──
  const [armed, setArmed] = useState(false);
  const keyBuffer = useRef("");
  const armTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── logo tap (mobile) ──
  const logoTaps = useRef(0);
  const logoTapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── shake state ──
  const shakeCount = useRef(0);
  const lastShakeTs = useRef(0);
  const lastAcc = useRef({ x: 0, y: 0, z: 0 });
  const motionGranted = useRef(false);
  const shakeResetTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── background wake-word rec ──
  const wakeRecRef = useRef<any>(null);
  const wakeActive = useRef(false);

  // ── open helper ──
  const open = () => {
    if (!ariaOpen) setAriaOpen(true);
  };

  /* ── 1. KEYBOARD unlock: type "unlock protocol" → arms → type "aria" ── */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (ariaOpen) {
        if (e.key === "Escape") setAriaOpen(false);
        return;
      }
      if (e.key.length !== 1) return;
      keyBuffer.current = (keyBuffer.current + e.key.toLowerCase()).slice(-20);

      if (!armed && keyBuffer.current.endsWith("unlock protocol")) {
        setArmed(true);
        keyBuffer.current = "";
        if (armTimerRef.current) clearTimeout(armTimerRef.current);
        armTimerRef.current = setTimeout(() => { setArmed(false); keyBuffer.current = ""; }, 30_000);
      }
      if (armed && keyBuffer.current.slice(-4) === "aria") {
        setArmed(false);
        open();
        keyBuffer.current = "";
        if (armTimerRef.current) clearTimeout(armTimerRef.current);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [ariaOpen, armed]);

  /* ── 2. LOGO TAP (mobile): tap logo 3× within 600 ms each ── */
  useEffect(() => {
    (window as any).__ariaLogoTap = () => {
      logoTaps.current += 1;
      if (logoTapTimer.current) clearTimeout(logoTapTimer.current);
      if (logoTaps.current >= 3) {
        logoTaps.current = 0;
        open();
      } else {
        logoTapTimer.current = setTimeout(() => { logoTaps.current = 0; }, 600);
      }
    };
    return () => { delete (window as any).__ariaLogoTap; };
  }, [ariaOpen]);

  /* ── 3. SHAKE unlock: shake device 3× quickly ── */
  useEffect(() => {
    if (ariaOpen) return;

    const onMotion = (e: DeviceMotionEvent) => {
      // Use raw acceleration (no gravity) for clean signal; fall back to withGravity
      const acc = e.acceleration ?? e.accelerationIncludingGravity;
      if (!acc) return;
      const x = acc.x ?? 0, y = acc.y ?? 0, z = acc.z ?? 0;
      // Vector magnitude — works regardless of device orientation/tilt
      const magnitude = Math.sqrt(x * x + y * y + z * z);

      const now = Date.now();
      if (magnitude > 15 && now - lastShakeTs.current > 180) {
        shakeCount.current++;
        lastShakeTs.current = now;

        if (shakeResetTimer.current) clearTimeout(shakeResetTimer.current);
        shakeResetTimer.current = setTimeout(() => { shakeCount.current = 0; }, 1800);

        if (shakeCount.current >= 3) {
          shakeCount.current = 0;
          open();
        }
      }
    };

    const attach = () => window.addEventListener("devicemotion", onMotion);

    // iOS 13+ requires DeviceMotion permission inside a real user gesture
    if (typeof (DeviceMotionEvent as any).requestPermission === "function") {
      const onTouch = () => {
        if (motionGranted.current) return;
        // Synchronous call inside gesture — Safari requires this
        Promise.resolve((DeviceMotionEvent as any).requestPermission())
          .then((result: string) => {
            if (result === "granted") { motionGranted.current = true; attach(); }
          }).catch(() => {});
      };
      window.addEventListener("touchstart", onTouch, { passive: true });
      return () => {
        window.removeEventListener("touchstart", onTouch);
        window.removeEventListener("devicemotion", onMotion);
      };
    } else {
      // Android / desktop — no permission needed
      attach();
      return () => window.removeEventListener("devicemotion", onMotion);
    }
  }, [ariaOpen]);

  /* ── 4. VOICE WAKE WORD (PC + Android): say "hey aria" or "aria unlock" ──
     Runs as a background continuous listener when the panel is closed.
     iOS Safari does not allow background SpeechRecognition, so this only
     works on Chrome/Edge desktop and Android Chrome.                         */
  useEffect(() => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) return;

    if (ariaOpen) {
      // Panel opened — kill the background listener
      wakeActive.current = false;
      try { wakeRecRef.current?.stop(); } catch { }
      wakeRecRef.current = null;
      return;
    }

    wakeActive.current = true;
    let rec: any = null;

    const start = () => {
      if (!wakeActive.current) return;
      try {
        rec = new SR();
        rec.continuous = false;
        rec.interimResults = false;
        rec.lang = "en-US";
        rec.onresult = (e: any) => {
          for (let i = e.resultIndex; i < e.results.length; i++) {
            if (!e.results[i].isFinal) continue;
            const txt = e.results[i][0].transcript.toLowerCase().trim();
            // Catch "hey aria", "hey area", "aria unlock", "unlock protocol"
            if (
              txt.includes("hey aria") ||
              txt.includes("hey area") ||
              txt.includes("aria unlock") ||
              txt.includes("unlock protocol")
            ) {
              wakeActive.current = false;
              open();
              return;
            }
          }
        };
        rec.onend = () => { if (wakeActive.current) setTimeout(start, 600); };
        rec.onerror = (e: any) => {
          // no-speech and aborted are normal — restart; others stop
          if (e.error === "no-speech" || e.error === "aborted") {
            if (wakeActive.current) setTimeout(start, 600);
          }
          // not-allowed means mic denied — give up silently
        };
        rec.start();
        wakeRecRef.current = rec;
      } catch { }
    };

    // Small delay so we don't steal the mic from the ARIA panel itself at launch
    const t = setTimeout(start, 1800);

    return () => {
      wakeActive.current = false;
      clearTimeout(t);
      try { rec?.stop(); } catch { }
      wakeRecRef.current = null;
    };
  }, [ariaOpen]);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
        <ARIAOverlay open={ariaOpen} onClose={() => setAriaOpen(false)} />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
